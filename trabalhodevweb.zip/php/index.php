<?php
include_once "./db/database.php";
include_once "./templates/header.php";
?>

<div class="jumbotron bg-white shadow-sm">
    <h1 class="display-4">Bem-vindo ao Sistema de Gerenciamento</h1>
    <p class="lead">Um sistema eficiente para gerenciar produtos e fornecedores.</p>
    <hr class="my-4">
    <p>Selecione uma opção para começar:</p>

    <div class="d-flex justify-content-center">
        <a class="btn btn-primary btn-lg mr-2" href="produtos.php" role="button">
            <i class="fas fa-boxes"></i> Gerenciar Produtos
        </a>
        <a class="btn btn-secondary btn-lg" href="fornecedores.php" role="button">
            <i class="fas fa-truck-moving"></i> Gerenciar Fornecedores
        </a>
    </div>
</div>

<style>
    .jumbotron {
        border-radius: 0.5rem;
    }

    .jumbotron .btn {
        padding: 0.75rem 1.5rem;
        font-size: 1.2rem;
    }

    .jumbotron i {
        margin-right: 0.5rem;
    }
</style>

<?php
include_once "./templates/footer.php";
?>
