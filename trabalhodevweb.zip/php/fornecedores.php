<body>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    
    <?php
    include_once "./db/database.php";
    $db = new Database();
    
    if (isset($_POST['save'])) {
        $db->createFornecedor($_POST['nome'], $_POST['contato']);
        echo '<script>
            Toastify({
                text: "✅ Fornecedor criado com sucesso!",
                duration: 3000,
                close: true,
                gravity: "top",
                position: "right",
                backgroundColor: "green",
                stopOnFocus: true,
            }).showToast();
        </script>';
    }
    if (isset($_POST['update'])) {
        $db->updateFornecedor($_POST['id'], $_POST['nome'], $_POST['contato']);
        echo '<script>
            Toastify({
                text: "✅ Fornecedor atualizado com sucesso!",
                duration: 3000,
                close: true,
                gravity: "top",
                position: "right",
                backgroundColor: "blue",
                stopOnFocus: true,
            }).showToast();
        </script>';
    }
    if (isset($_GET['delete'])) {
        $db->deleteFornecedor($_GET['delete']);
        echo '<script>
            Toastify({
                text: "❌ Fornecedor excluído com sucesso!",
                duration: 3000,
                close: true,
                gravity: "top",
                position: "right",
                backgroundColor: "red",
                stopOnFocus: true,
            }).showToast();
        </script>';
    }
    
    $fornecedores = $db->getAllFornecedores();
    
    include_once "./templates/header.php";
    ?>
    
    <div class="container my-4">
        <h2>Gerenciar Fornecedores</h2>
        <form method="post" action="fornecedores.php" class="mb-3">
            <input type="hidden" name="id" value="">
            <div class="form-group">
                <label for="nome">Nome do Fornecedor</label>
                <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome do Fornecedor" required>
            </div>
            <div class="form-group">
                <label for="contato">Contato</label>
                <input type="text" class="form-control" id="contato" name="contato" placeholder="Contato">
            </div>
            <button type="submit" name="save" class="btn btn-primary">Salvar Fornecedor</button>
        </form>
    
        <table class="table table-bordered table-hover">
            <thead class="thead-light">
                <tr>
                    <th>Nome</th>
                    <th>Contato</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($fornecedores as $fornecedor) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($fornecedor['nome']); ?></td>
                        <td><?php echo htmlspecialchars($fornecedor['contato']); ?></td>
                        <td>
                            <a href="#" class="btn btn-sm btn-info btn-edit-fornecedor" data-id="<?php echo $fornecedor['id']; ?>" data-nome="<?php echo htmlspecialchars($fornecedor['nome']); ?>" data-contato="<?php echo htmlspecialchars($fornecedor['contato']); ?>">
                                Editar
                            </a>
                            <a href="fornecedores.php?delete=<?php echo $fornecedor['id']; ?>" class="btn btn-sm btn-danger">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Modal para Edição de Fornecedor -->
    <div class="modal fade" id="editFornecedorModal" tabindex="-1" role="dialog" aria-labelledby="editFornecedorModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editFornecedorModalLabel">Editar Fornecedor</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" action="fornecedores.php">
                    <div class="modal-body">
                        <input type="hidden" name="id" id="edit_fornecedor_id">
                        <div class="form-group">
                            <label for="edit_fornecedor_nome">Nome do Fornecedor</label>
                            <input type="text" class="form-control" id="edit_fornecedor_nome" name="nome" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_fornecedor_contato">Contato</label>
                            <input type="text" class="form-control" id="edit_fornecedor_contato" name="contato">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" name="update" class="btn btn-primary">Salvar Alterações</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        document.querySelectorAll('.btn-edit-fornecedor').forEach(btn => {
            btn.addEventListener('click', function() {
                var fornecedorId = this.getAttribute('data-id');
                var fornecedorNome = this.getAttribute('data-nome');
                var fornecedorContato = this.getAttribute('data-contato');
    
                document.getElementById('edit_fornecedor_id').value = fornecedorId;
                document.getElementById('edit_fornecedor_nome').value = fornecedorNome;
                document.getElementById('edit_fornecedor_contato').value = fornecedorContato;
    
                $('#editFornecedorModal').modal('show');
            });
        });
    </script>
    
    <?php include_once "./templates/footer.php"; ?>
</body>