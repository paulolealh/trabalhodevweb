import sqlite3


conexao = sqlite3.connect('database.db')
con = conexao.cursor()
con.execute('''
UPDATE produtos SET quantidade_em_estoque=9 WHERE id=6''')
conexao.commit()
conexao.close()
