<?php
include_once "./db/database.php";

if (isset($_GET['id']) && isset($_GET['quantidade'])) {
    $id = $_GET['id'];
    $quantidade = $_GET['quantidade'];

    $db = new Database();
    $produto = $db->getProdutoById($id);

    if ($produto) {
        $db->atualizaQuantidadeProdutoSaida($id, $quantidade);
        // Retorne uma resposta de sucesso, se necessário
        echo "Estoque atualizado com sucesso.";
    } else {
        // Produto não encontrado
        http_response_code(404);
        echo "Produto não encontrado.";
    }
} else {
    // Parâmetros inválidos
    http_response_code(400);
    echo "Parâmetros inválidos.";
}
?>

