<body>

    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

    <?php
    include_once "./db/database.php";
    $db = new Database();

    if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] == 0) {
        $allowedTypes = ['image/jpeg', 'image/png'];
        $fileType = $_FILES['imagem']['type'];

        if (in_array($fileType, $allowedTypes)) {
            $imagem = file_get_contents($_FILES['imagem']['tmp_name']);
            $imagem_base64 = base64_encode($imagem);

            if (isset($_POST['save'])) {
                $db->createProduto($_POST['nome'], $_POST['descricao'], $_POST['categoria'], $_POST['preco'], $imagem_base64, $_POST['fornecedor_id']);
                echo '<script>
                    Toastify({
                        text: "✅ Produto criado com sucesso!",
                        duration: 3000,
                        close: true,
                        gravity: "top",
                        position: "right",
                        backgroundColor: "green",
                        stopOnFocus: true,
                    }).showToast();
                </script>';
            }
        } else {
            echo "Formato de arquivo inválido. Apenas JPEG e PNG são permitidos.";
        }
    }
    if (isset($_POST['update'])) {
        $imagem_base64 = null;
        $alterarImagem = false;

        if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] == 0) {
            $allowedTypes = ['image/jpeg', 'image/png'];
            $fileType = $_FILES['imagem']['type'];

            if (in_array($fileType, $allowedTypes)) {
                $imagem = file_get_contents($_FILES['imagem']['tmp_name']);
                $imagem_base64 = base64_encode($imagem);
                $alterarImagem = true;
            } else {
                echo "Formato de arquivo inválido. Apenas JPEG e PNG são permitidos.";
            }
        }
        $db->updateProduto($_POST['id'], $_POST['nome'], $_POST['descricao'], $_POST['categoria'], $_POST['preco'], $imagem_base64, $_POST['fornecedor_id'], $alterarImagem);
        echo '<script>
            Toastify({
                text: "✅ Produto atualizado com sucesso!",
                duration: 3000,
                close: true,
                gravity: "top",
                position: "right",
                backgroundColor: "blue",
                stopOnFocus: true,
            }).showToast();
        </script>';
    }
    if (isset($_GET['delete'])) {
        $db->deleteProduto($_GET['delete']);
        echo '<script>
            Toastify({
                text: "❌ Produto excluído com sucesso!",
                duration: 3000,
                close: true,
                gravity: "top",
                position: "right",
                backgroundColor: "red",
                stopOnFocus: true,
            }).showToast();
        </script>';
    }

    $produtos = $db->getAllProdutos();
    $fornecedores = $db->getAllFornecedores();

    include_once "./templates/header.php";
    ?>

    <div class="container my-4">
        <h2>Gerenciar Produtos</h2>
        <form method="post" action="produtos.php" class="mb-3" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $produto['id'] ?? ''; ?>">

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="nome">Nome do Produto</label>
                        <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome do Produto" value="<?php echo $produto['nome'] ?? ''; ?>" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="categoria">Categoria</label>
                        <input type="text" class="form-control" id="categoria" name="categoria" placeholder="Categoria" value="<?php echo $produto['categoria'] ?? ''; ?>">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="descricao">Descrição</label>
                        <input type="text" class="form-control" id="descricao" name="descricao" placeholder="Descrição" value="<?php echo $produto['descricao'] ?? ''; ?>">
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="preco">Preço</label>
                        <input type="number" class="form-control" id="preco" name="preco" placeholder="Preço" value="<?php echo $produto['preco'] ?? ''; ?>">
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label for="imagem">Imagem</label>
                <input type="file" class="form-control-file" id="imagem" name="imagem" accept="image/png, image/jpeg">
            </div>

            <div class="form-group">
                <label for="fornecedor_nome">Fornecedor</label>
                <div class="input-group">
                    <input type="text" class="form-control" id="fornecedor_nome" placeholder="Selecione um Fornecedor" readonly>
                    <input type="hidden" name="fornecedor_id" id="fornecedor_id">
                    <div class="input-group-append">
                        <button type="button" class="btn btn-outline-secondary" data-toggle="modal" data-target="#fornecedorModal">Selecionar</button>
                    </div>
                </div>
            </div>

            <button type="submit" name="save" class="btn btn-primary">Salvar Produto</button>
        </form>


        <!-- Tabela de Produtos -->
        <table class="table table-bordered table-hover">
            <thead class="thead-light">
                <tr>
                    <th>Nome</th>
                    <th>Descrição</th>
                    <th>Categoria</th>
                    <th>Preço</th>
                    <th>Imagem</th>
                    <th>Fornecedor</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($produtos as $produto) :
                    $nome_do_fornecedor = $db->getFornecedorNomePorId($produto['fornecedor_id']);
                ?>
                    <tr>
                        <td><?php echo htmlspecialchars($produto['nome']); ?></td>
                        <td><?php echo htmlspecialchars($produto['descricao']); ?></td>
                        <td><?php echo htmlspecialchars($produto['categoria']); ?></td>
                        <td><?php echo htmlspecialchars($produto['preco']); ?></td>
                        <td>
                            <?php if (!empty($produto['imagem'])) : ?>
                                <img src="data:image/jpeg;base64,<?php echo $produto['imagem']; ?>" style="width: 100px; height: 100px;">
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($produto['fornecedor_id']); ?></td>
                        <td>
                            <a href="#" class="btn btn-sm btn-info btn-edit" data-id="<?php echo $produto['id']; ?>" data-imagem="<?php echo $produto['imagem']; ?>" data-fornecedor_nome="<?php echo $nome_do_fornecedor; ?>" data-nome="<?php echo $produto['nome']; ?>" data-descricao="<?php echo $produto['descricao']; ?>" data-categoria="<?php echo $produto['categoria']; ?>" data-preco="<?php echo $produto['preco']; ?>" data-imagem="<?php echo $produto['imagem']; ?>" data-fornecedor_id="<?php echo $produto['fornecedor_id']; ?>">
                                Editar
                            </a>
                            <a href="produtos.php?delete=<?php echo $produto['id']; ?>" class="btn btn-sm btn-danger">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>


    <!-- Modal para Edição de Produto -->
    <div class="modal fade" id="editProdutoModal" tabindex="-1" role="dialog" aria-labelledby="editProdutoModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editProdutoModalLabel">Editar Produto</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" action="produtos.php" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" name="id" id="edit_id">
                        <div class="form-group">
                            <label for="edit_nome">Nome do Produto</label>
                            <input type="text" class="form-control" id="edit_nome" name="nome">
                        </div>
                        <div class="form-group">
                            <label for="edit_descricao">Descrição</label>
                            <input type="text" class="form-control" id="edit_descricao" name="descricao">
                        </div>
                        <div class="form-group">
                            <label for="edit_categoria">Categoria</label>
                            <input type="text" class="form-control" id="edit_categoria" name="categoria">
                        </div>
                        <div class="form-group">
                            <label for="edit_preco">Preço</label>
                            <input type="number" class="form-control" id="edit_preco" name="preco">
                        </div>
                        <div class="form-group">
                            <label for="edit_imagem">Imagem Atual</label>
                            <div id="currentImageContainer" style="margin-bottom: 10px;">
                            </div>
                            <label for="edit_imagem">Trocar Imagem</label>
                            <input type="file" class="form-control-file" id="edit_imagem" name="imagem" accept="image/png, image/jpeg">
                        </div>

                        <div class="form-group">
                            <label for="edit_fornecedor_nome">Fornecedor</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="edit_fornecedor_nome" placeholder="Selecione um Fornecedor" readonly>
                                <input type="hidden" name="fornecedor_id" id="edit_fornecedor_id">
                                <div class="input-group-append">
                                    <button type="button" class="btn btn-outline-secondary" data-toggle="modal" data-target="#fornecedorModal">Selecionar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" name="update" class="btn btn-primary">Salvar Alterações</button>
                    </div>
                </form>
            </div>
        </div>
    </div>



    <!-- Modal para escolher o fornecedor -->
    <div class="modal fade" id="fornecedorModal" tabindex="-1" role="dialog" aria-labelledby="fornecedorModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="fornecedorModalLabel">Escolha um Fornecedor</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php if (!empty($fornecedores)) : ?>
                        <ul class="list-group">
                            <?php foreach ($fornecedores as $fornecedor) : ?>
                                <li class="list-group-item list-group-item-action" data-id="<?php echo $fornecedor['id']; ?>" data-nome="<?php echo htmlspecialchars($fornecedor['nome']); ?>">
                                    <?php echo htmlspecialchars($fornecedor['nome']); ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else : ?>
                        <p>Sem fornecedores disponíveis.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.querySelectorAll('.btn-edit').forEach(btn => {
            btn.addEventListener('click', function() {
                var produto = {
                    id: this.getAttribute('data-id'),
                    nome: this.getAttribute('data-nome'),
                    descricao: this.getAttribute('data-descricao'),
                    categoria: this.getAttribute('data-categoria'),
                    preco: this.getAttribute('data-preco'),
                    fornecedor_id: this.getAttribute('data-fornecedor_id'),
                    fornecedor_nome: this.getAttribute('data-fornecedor_nome'),
                    imagem: this.getAttribute('data-imagem')
                };
                var currentImageContainer = document.getElementById('currentImageContainer');
                if (produto.imagem) {
                    currentImageContainer.innerHTML = '<img src="data:image/jpeg;base64,' + produto.imagem + '" style="width: 100px; height: 100px;">';
                } else {
                    currentImageContainer.innerHTML = 'Nenhuma imagem disponível';
                }
                document.getElementById('edit_id').value = produto.id;
                document.getElementById('edit_nome').value = produto.nome;
                document.getElementById('edit_descricao').value = produto.descricao;
                document.getElementById('edit_categoria').value = produto.categoria;
                document.getElementById('edit_preco').value = produto.preco;
                document.getElementById('edit_fornecedor_id').value = produto.fornecedor_id;

                $('#editProdutoModal').modal('show');
            });
        });
        document.querySelectorAll('#fornecedorModal .list-group-item').forEach(item => {
            item.addEventListener('click', function() {
                var fornecedorId = this.getAttribute('data-id');
                var fornecedorNome = this.getAttribute('data-nome');

                if ($('#editProdutoModal').is(':visible')) {
                    document.getElementById('edit_fornecedor_nome').value = fornecedorNome;
                    document.getElementById('edit_fornecedor_id').value = fornecedorId;
                } else {
                    document.getElementById('fornecedor_nome').value = fornecedorNome;
                    document.getElementById('fornecedor_id').value = fornecedorId;
                }
                $('#fornecedorModal').modal('hide');
            });
        });
    </script>

    <?php include_once "./templates/footer.php"; ?>
</body>
<!-- Seção de Controle de Estoque(victor damasceno) -->
<div class="container my-4">
    <h2>Controle de Estoque</h2>

    <!-- Tabela de Estoque -->
    <table class="table table-bordered table-hover">
        <thead class="thead-light">
            <tr>
                <th>Produto</th>
                <th>Quantidade em Estoque</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($produtos as $produto) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($produto['nome']); ?></td>
                    <td><?php echo htmlspecialchars($produto['quantidade_em_estoque']); ?></td>
                    <td>
                        <button class="btn btn-sm btn-success btn-entrada" data-id="<?php echo $produto['id']; ?>">Entrada</button>
                        <button class="btn btn-sm btn-warning btn-saida" data-id="<?php echo $produto['id']; ?>">Saída</button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
    document.querySelectorAll('.btn-entrada').forEach(btn => {
        btn.addEventListener('click', function() {
            var produtoId = this.getAttribute('data-id');
            var quantidade = prompt('Digite a quantidade de entrada:');
            if (quantidade !== null && quantidade !== '') {
                fetch('atualiza_estoque_entrada.php?id=' + produtoId + '&quantidade=' + quantidade, {
                    method: 'GET'
                }).then(response => {
                    // Atualização bem-sucedida
                    alert('Estoque atualizado com sucesso.');
                }).catch(error => {
                    // Trate os erros, se houver
                    console.error('Erro ao atualizar estoque:', error);
                });
            }
        });
    });


    document.querySelectorAll('.btn-saida').forEach(btn => {
        btn.addEventListener('click', function() {
            var produtoId = this.getAttribute('data-id');
            var quantidade = prompt('Digite a quantidade de saída:');
            if (quantidade !== null && quantidade !== '') {
                fetch('atualiza_estoque_saida.php?id=' + produtoId + '&quantidade=-' + quantidade, {
                    method: 'GET'
                }).then(response => {
                    // Atualização bem-sucedida
                    alert('Estoque atualizado com sucesso.');
                }).catch(error => {
                    // Trate os erros, se houver
                    console.error('Erro ao atualizar estoque:', error);
                });
                        
            }
        });
    });
</script>