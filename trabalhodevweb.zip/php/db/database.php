<?php
class Database {
    private $db;

    public function __construct() {
        $this->db = new PDO('sqlite:'.dirname(__FILE__).'/database.db');
        $this->createTables();
    }

    private function createTables() {
        $queries = [
            "CREATE TABLE IF NOT EXISTS produtos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT,
                descricao TEXT,
                categoria TEXT,
                preco REAL,
                quantidade_em_estoque INTEGER, 
                imagem TEXT,
                fornecedor_id INTEGER,
                FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id)
            )",
            "CREATE TABLE IF NOT EXISTS fornecedores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT,
                contato TEXT
            )"
        ];

        foreach ($queries as $query) {
            $this->db->exec($query);
        }
    }
    public function getAllProdutos() {
        $stmt = $this->db->prepare("SELECT * FROM produtos");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }    
    public function createProduto($nome, $descricao, $categoria, $preco, $imagem, $fornecedor_id) {
        $sql = "INSERT INTO produtos (nome, descricao, categoria, preco, imagem, fornecedor_id) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$nome, $descricao, $categoria, $preco, $imagem, $fornecedor_id]);
    }
    public function readProduto($id) {
        $sql = "SELECT * FROM produtos WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function updateProduto($id, $nome, $descricao, $categoria, $preco, $imagem_base64, $fornecedor_id, $alterarImagem) {
        if ($alterarImagem && $imagem_base64 !== null) {
            $sql = "UPDATE produtos SET nome = ?, descricao = ?, categoria = ?, preco = ?, imagem = ?, fornecedor_id = ? WHERE id = ?";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$nome, $descricao, $categoria, $preco, $imagem_base64, $fornecedor_id, $id]);
        } else {
            $sql = "UPDATE produtos SET nome = ?, descricao = ?, categoria = ?, preco = ?, fornecedor_id = ? WHERE id = ?";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$nome, $descricao, $categoria, $preco, $fornecedor_id, $id]);
        }
    }
    
    public function deleteProduto($id) {
        $sql = "DELETE FROM produtos WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);
    }
    public function getAllFornecedores() {
        $stmt = $this->db->prepare("SELECT * FROM fornecedores");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    public function getFornecedorNomePorId($fornecedor_id) {
        $stmt = $this->db->prepare("SELECT nome FROM fornecedores WHERE id = ?");
        $stmt->execute([$fornecedor_id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ? $resultado['nome'] : null;
    }
    public function createFornecedor($nome, $contato) {
        $sql = "INSERT INTO fornecedores (nome, contato) VALUES (?, ?)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$nome, $contato]);
    }
    public function readFornecedor($id) {
        $sql = "SELECT * FROM fornecedores WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function updateFornecedor($id, $nome, $contato) {
        $sql = "UPDATE fornecedores SET nome = ?, contato = ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$nome, $contato, $id]);
    }
    public function deleteFornecedor($id) {
        $sql = "DELETE FROM fornecedores WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);
    }
//--------------------------------------- vinicius mendes
    public function getProdutoById($id) {
        $stmt = $this->db->prepare("SELECT * FROM produtos WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function atualizaQuantidadeProdutoEntrada($id, $quantidade) {
        $sql = "UPDATE produtos SET quantidade_em_estoque = quantidade_em_estoque + ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$quantidade, $id]);
    }
  

    public function atualizaQuantidadeProdutoSaida($id, $quantidade) {
        $sql = "UPDATE produtos SET quantidade_em_estoque = quantidade_em_estoque-? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$quantidade, $id]);

    }
}

return new Database();
?>
